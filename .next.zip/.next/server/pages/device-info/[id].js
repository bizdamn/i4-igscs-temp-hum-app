"use strict";
(() => {
var exports = {};
exports.id = 212;
exports.ids = [212];
exports.modules = {

/***/ 1052:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const entriesSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    deviceName: {
        type: String,
        required: true
    },
    temperature: {
        type: String,
        required: true
    },
    humidity: {
        type: String,
        required: true
    },
    timestamp: {
        type: Date,
        required: true
    }
});
const Entries = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Entries) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Entries', entriesSchema, 'temp-humidity-entries');
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Entries);


/***/ }),

/***/ 3720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ DevicePage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material/Grid"
var Grid_ = __webpack_require__(5612);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);
// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(2245);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);
;// CONCATENATED MODULE: external "danfojs"
const external_danfojs_namespaceObject = require("danfojs");
// EXTERNAL MODULE: ./models/Entries.js
var Entries = __webpack_require__(1052);
// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./models/DeviceCalibration.js

const deviceCalibrationSchema = new (external_mongoose_default()).Schema({
    deviceName: {
        type: String,
        required: true,
        unique: true
    },
    temperature_calibration: {
        type: Number,
        required: true
    },
    humidity_calibration: {
        type: Number,
        required: true
    }
});
const DeviceCalibration = (external_mongoose_default()).models.DeviceCalibration || external_mongoose_default().model('DeviceCalibration', deviceCalibrationSchema, 'device-calibration');
/* harmony default export */ const models_DeviceCalibration = (DeviceCalibration);

// EXTERNAL MODULE: ./utils/db.js
var db = __webpack_require__(9972);
// EXTERNAL MODULE: external "recharts"
var external_recharts_ = __webpack_require__(3655);
// EXTERNAL MODULE: external "@mui/material/TextField"
var TextField_ = __webpack_require__(6042);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField_);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
;// CONCATENATED MODULE: external "@mui/material/ListItem"
const ListItem_namespaceObject = require("@mui/material/ListItem");
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem_namespaceObject);
// EXTERNAL MODULE: external "@mui/material/Stack"
var Stack_ = __webpack_require__(8742);
var Stack_default = /*#__PURE__*/__webpack_require__.n(Stack_);
;// CONCATENATED MODULE: external "@mui/material/ListItemText"
const ListItemText_namespaceObject = require("@mui/material/ListItemText");
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText_namespaceObject);
// EXTERNAL MODULE: external "@mui/material/Paper"
var Paper_ = __webpack_require__(1598);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper_);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: external "@mui/icons-material/NetworkCheck"
const NetworkCheck_namespaceObject = require("@mui/icons-material/NetworkCheck");
var NetworkCheck_default = /*#__PURE__*/__webpack_require__.n(NetworkCheck_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/ArrowDownward"
const ArrowDownward_namespaceObject = require("@mui/icons-material/ArrowDownward");
var ArrowDownward_default = /*#__PURE__*/__webpack_require__.n(ArrowDownward_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Outbound"
const Outbound_namespaceObject = require("@mui/icons-material/Outbound");
var Outbound_default = /*#__PURE__*/__webpack_require__.n(Outbound_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/ListItemAvatar"
const ListItemAvatar_namespaceObject = require("@mui/material/ListItemAvatar");
var ListItemAvatar_default = /*#__PURE__*/__webpack_require__.n(ListItemAvatar_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Avatar"
const Avatar_namespaceObject = require("@mui/material/Avatar");
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar_namespaceObject);
// EXTERNAL MODULE: external "react-chartjs-2"
var external_react_chartjs_2_ = __webpack_require__(7051);
// EXTERNAL MODULE: ./Layout/Layout.js + 9 modules
var Layout = __webpack_require__(1776);
// EXTERNAL MODULE: ./utils/DataStore.js
var DataStore = __webpack_require__(7820);
// EXTERNAL MODULE: external "notistack"
var external_notistack_ = __webpack_require__(3142);
;// CONCATENATED MODULE: ./components/Data/DeviceInfo.jsx




function DeviceInfo(props) {
    const { 0: DeviceInfo1 , 1: setDeviceInfo  } = useState({
        devEUI: null,
        applicationID: null,
        variables: null,
        tags: null,
        description: null,
        deviceProfileID: null,
        isDisabled: null,
        referenceAltitude: null,
        name: null,
        skipFCntCheck: null,
        lastSeenAt: null,
        location: null,
        deviceStatusMargin: null,
        deviceStatusBattery: null
    });
    var date = new Date(DeviceInfo1.lastSeenAt);
    var formattted_last_seen = date.toLocaleString();
    return(/*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsx(Grid, {
            container: true,
            spacing: 0,
            direction: "column",
            alignItems: "center",
            justifyContent: "center",
            children: /*#__PURE__*/ _jsx(Paper, {
                sx: {
                    padding: 3
                },
                children: /*#__PURE__*/ _jsxs("table", {
                    className: "table table-striped table-hover",
                    children: [
                        /*#__PURE__*/ _jsx("thead", {
                            children: /*#__PURE__*/ _jsxs("tr", {
                                children: [
                                    /*#__PURE__*/ _jsx("th", {
                                        children: "Parameter"
                                    }),
                                    /*#__PURE__*/ _jsx("th", {
                                        children: "Value"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ _jsx("tbody", {
                            children: /*#__PURE__*/ _jsxs("tr", {
                                children: [
                                    /*#__PURE__*/ _jsx("td", {
                                        children: "Device Name"
                                    }),
                                    /*#__PURE__*/ _jsx("td", {
                                        children: DeviceInfo1.name
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    }));
};

// EXTERNAL MODULE: ./components/DatePickerComponent/DatePickerComponent.jsx
var DatePickerComponent = __webpack_require__(8832);
// EXTERNAL MODULE: external "@mui/material/Button"
var Button_ = __webpack_require__(3819);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./pages/device-info/[id].js






























function DevicePage({ tempArray , humArray , deviceCalibration  }) {
    const router = (0,router_.useRouter)();
    const { id  } = router.query;
    const { state  } = (0,external_react_.useContext)(DataStore/* DataStore */.K);
    const { userInfo  } = state;
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0);
    (0,external_react_.useEffect)(()=>{
        if (!userInfo) {
            router.push('/login');
        }
        temperatureFilter();
    }, [
        userInfo,
        router
    ]);
    const { enqueueSnackbar , closeSnackbar  } = (0,external_notistack_.useSnackbar)();
    const { 0: startDate , 1: SetStartDate  } = (0,external_react_.useState)(external_moment_default()(currentDate, "YYYY-MM-DDTHH:mm:ss").format("YYYY-MM-DD"));
    const { 0: endDate , 1: SetEndDate  } = (0,external_react_.useState)(external_moment_default()(currentDate, "YYYY-MM-DDTHH:mm:ss").add(1, 'days').format("YYYY-MM-DD"));
    const { 0: current_humidity_calibration , 1: setCurrent_humidity_calibration  } = (0,external_react_.useState)(deviceCalibration[0].humidity_calibration);
    const { 0: current_temperature_calibration , 1: setCurrent_temperature_calibration  } = (0,external_react_.useState)(deviceCalibration[0].temperature_calibration);
    const { 0: tempMinArray , 1: setTempMinArray  } = (0,external_react_.useState)([]);
    const { 0: tempMaxArray , 1: setTempMaxArray  } = (0,external_react_.useState)([]);
    const { 0: tempAvgArray , 1: setTempAvgArray  } = (0,external_react_.useState)([]);
    const { 0: humMinArray , 1: setHumMinArray  } = (0,external_react_.useState)([]);
    const { 0: humMaxArray , 1: setHumMaxArray  } = (0,external_react_.useState)([]);
    const { 0: humAvgArray , 1: setHumAvgArray  } = (0,external_react_.useState)([]);
    async function temperatureFilter() {
        closeSnackbar();
        try {
            const { data  } = await external_axios_default().post('https://i4-server-temp-hum-chart.igscsi4server.com/', {
                start_date: startDate,
                end_date: endDate,
                deviceName: id
            });
            console.log(data);
            setTempMinArray(data.tempData.minArray);
            setTempMaxArray(data.tempData.maxArray);
            setTempAvgArray(data.tempData.avgArray);
            setHumMinArray(data.humData.minArray);
            setHumMaxArray(data.humData.maxArray);
            setHumAvgArray(data.humData.avgArray);
            setHumAvgArray(data.humData.avgArray);
            enqueueSnackbar('Filtered', {
                variant: 'success'
            });
        } catch (e) {
            console.log(e);
        }
    }
    async function updateCallibration() {
        closeSnackbar();
        try {
            const { data  } = await external_axios_default().put('/api/device-calibration/set-device-calibration', {
                temperatureCalibration: current_temperature_calibration,
                humidityCalibration: current_humidity_calibration,
                deviceName: id
            });
            enqueueSnackbar('Updated Successfully', {
                variant: 'success'
            });
        } catch (err) {
            enqueueSnackbar(err, {
                variant: 'error'
            });
        }
    }
    // TABLE DATA
    const Temperaturedata = {
        labels: [
            "12 AM",
            "1 AM",
            "2 AM",
            "3 AM",
            "4 AM",
            "5 AM",
            "6 AM",
            "7 AM",
            "8 AM",
            "9 AM",
            "10 AM",
            "11 AM",
            "12 PM",
            "1PM",
            "2 PM",
            "3 PM",
            "4 PM",
            "5 PM",
            "6 PM",
            "7 PM",
            "8 PM",
            "9 PM",
            "10 PM",
            "11 PM"
        ],
        datasets: [
            {
                label: "Min Temperature",
                data: tempMinArray,
                borderColor: [
                    "red", 
                ],
                borderWidth: 1
            },
            {
                label: "Max Temperature",
                data: tempMaxArray,
                borderWidth: 1,
                borderColor: [
                    "blue", 
                ]
            },
            {
                label: "Average Temperature",
                data: tempAvgArray,
                borderWidth: 1,
                borderColor: [
                    "black", 
                ]
            }, 
        ]
    };
    const Humiditydata = {
        labels: [
            "12 AM",
            "1 AM",
            "2 AM",
            "3 AM",
            "4 AM",
            "5 AM",
            "6 AM",
            "7 AM",
            "8 AM",
            "9 AM",
            "10 AM",
            "11 AM",
            "12 PM",
            "1PM",
            "2 PM",
            "3 PM",
            "4 PM",
            "5 PM",
            "6 PM",
            "7 PM",
            "8 PM",
            "9 PM",
            "10 PM",
            "11 PM"
        ],
        datasets: [
            {
                label: "Min Humidity",
                data: humMinArray,
                borderColor: [
                    "red", 
                ],
                borderWidth: 1
            },
            {
                label: "Max Humidity",
                data: humMaxArray,
                borderWidth: 1,
                borderColor: [
                    "blue", 
                ]
            },
            {
                label: "Average Humidity",
                data: humAvgArray,
                borderWidth: 1,
                borderColor: [
                    "black", 
                ]
            }, 
        ]
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                style: {
                    backgroundColor: '#9d2eff',
                    color: 'white'
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    sx: {
                        mb: 3
                    },
                    variant: "h3",
                    align: "center",
                    children: "Zone Name"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                sx: {
                    my: 3
                },
                container: true,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        lg: 5,
                        xs: 12
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        lg: 7,
                        xs: 12,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                                direction: "row",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(DatePickerComponent/* default */.Z, {
                                        startDate: startDate,
                                        SetStartDate: SetStartDate,
                                        endDate: endDate,
                                        SetEndDate: SetEndDate
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                            onClick: ()=>temperatureFilter()
                                            ,
                                            variant: "outlined",
                                            children: "Filter"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Stack_default()), {
                                spacing: 2,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            style: {
                                                border: "2px solid #9013FE",
                                                borderRadius: "1rem"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_recharts_.ResponsiveContainer, {
                                                className: "p-0",
                                                width: "100%",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "p-1",
                                                            style: {
                                                                backgroundColor: "#9013FE",
                                                                borderRadius: "1rem",
                                                                color: "#fff",
                                                                textAlign: "center"
                                                            },
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                children: "Temperature Trend"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            style: {
                                                                padding: "3px"
                                                            },
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_chartjs_2_.Line, {
                                                                height: 150,
                                                                data: Temperaturedata
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            style: {
                                                border: "2px solid #9013FE",
                                                borderRadius: "1rem"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_recharts_.ResponsiveContainer, {
                                                className: "p-0",
                                                width: "100%",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "p-1",
                                                            style: {
                                                                backgroundColor: "#9013FE",
                                                                borderRadius: "1rem",
                                                                color: "#fff",
                                                                textAlign: "center"
                                                            },
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                children: "Humidity Trend"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            style: {
                                                                padding: "3px"
                                                            },
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_chartjs_2_.Line, {
                                                                height: 150,
                                                                data: Humiditydata
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            userInfo && userInfo.isAdmin == true ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                style: {
                    marginTop: "5rem"
                },
                container: true,
                spacing: 4,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        component: (Paper_default()),
                        item: true,
                        sx: {
                            p: 3
                        },
                        lg: 6,
                        xs: 12,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                sx: {
                                    my: 3
                                },
                                container: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                    item: true,
                                    xs: 12,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                        container: true,
                                        spacing: 2,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                                item: true,
                                                xs: 4,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "p",
                                                    sx: {
                                                        fontWeight: 700
                                                    },
                                                    children: "Temperature"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                                item: true,
                                                xs: 8,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowDownward_default()), {})
                                                                })
                                                            }),
                                                            tempArray[tempArray.length - 1] ? /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                                primary: "Input",
                                                                secondary: (parseFloat(tempArray[tempArray.length - 1]) - parseFloat(current_temperature_calibration)).toFixed(2)
                                                            }) : /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                                primary: "Input",
                                                                secondary: "--"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((NetworkCheck_default()), {})
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                                placeholder: current_temperature_calibration,
                                                                onChange: (e)=>{
                                                                    setCurrent_temperature_calibration(e.target.value);
                                                                },
                                                                type: "number",
                                                                fullWidth: true,
                                                                id: "outlined-basic",
                                                                label: "Temperature Calibration",
                                                                variant: "outlined"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Outbound_default()), {})
                                                                })
                                                            }),
                                                            tempArray[tempArray.length - 1] ? /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                                primary: "Output",
                                                                secondary: parseFloat(tempArray[tempArray.length - 1]).toFixed(2)
                                                            }) : /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                                primary: "Output",
                                                                secondary: "--"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                item: true,
                                xs: 12,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                    container: true,
                                    spacing: 2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                            item: true,
                                            xs: 4,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "p",
                                                sx: {
                                                    fontWeight: 700
                                                },
                                                children: "Humidity"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                            item: true,
                                            xs: 8,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowDownward_default()), {})
                                                            })
                                                        }),
                                                        humArray[humArray.length - 1] ? /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                            primary: "Input",
                                                            secondary: (parseFloat(humArray[humArray.length - 1]) - parseFloat(current_humidity_calibration)).toFixed(2)
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                            primary: "Input",
                                                            secondary: "--"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((NetworkCheck_default()), {})
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                            placeholder: current_humidity_calibration,
                                                            onChange: (e)=>{
                                                                setCurrent_humidity_calibration(e.target.value);
                                                            },
                                                            type: "number",
                                                            fullWidth: true,
                                                            label: "Humidity Calibration",
                                                            variant: "outlined"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Outbound_default()), {})
                                                            })
                                                        }),
                                                        humArray[humArray.length - 1] ? /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                            primary: "Output",
                                                            secondary: parseFloat(humArray[humArray.length - 1]).toFixed(2)
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                            primary: "Output",
                                                            secondary: "--"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                    sx: {
                                                        backgroundColor: "#38B6FF",
                                                        p: 1
                                                    },
                                                    onClick: ()=>updateCallibration()
                                                    ,
                                                    variant: "contained",
                                                    children: "  Save"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        lg: 6,
                        md: 6,
                        sm: 6,
                        xs: 12
                    })
                ]
            }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
        ]
    }));
};
async function getServerSideProps(ctx) {
    const { id  } = ctx.query;
    await db/* default.connect */.Z.connect();
    const result = await Entries/* default.find */.Z.find({
        deviceName: id
    }).lean();
    const deviceCalibration = await models_DeviceCalibration.find({
        deviceName: id
    }).lean();
    await db/* default.disconnect */.Z.disconnect();
    if (result.length > 0) {
        const df = new external_danfojs_namespaceObject.DataFrame(result);
        const temperaturedf = df.column("temperature");
        const humiditydf = df.column("humidity");
        return {
            props: {
                tempArray: temperaturedf.$data,
                humArray: humiditydf.$data,
                deviceCalibration: deviceCalibration.map(db/* default.convertDocToObj */.Z.convertDocToObj)
            }
        };
    } else {
        return {
            props: {
                tempArray: [],
                humArray: [],
                deviceCalibration: deviceCalibration.map(db/* default.convertDocToObj */.Z.convertDocToObj)
            }
        };
    }
}


/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 4628:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles/colorManipulator");

/***/ }),

/***/ 2105:
/***/ ((module) => {

module.exports = require("@material-ui/icons");

/***/ }),

/***/ 3349:
/***/ ((module) => {

module.exports = require("@material-ui/styles");

/***/ }),

/***/ 6464:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountTree");

/***/ }),

/***/ 9560:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AddTask");

/***/ }),

/***/ 1709:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CellTowerSharp");

/***/ }),

/***/ 1050:
/***/ ((module) => {

module.exports = require("@mui/icons-material/DataObject");

/***/ }),

/***/ 5711:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SensorsSharp");

/***/ }),

/***/ 4428:
/***/ ((module) => {

module.exports = require("@mui/icons-material/StorageSharp");

/***/ }),

/***/ 752:
/***/ ((module) => {

module.exports = require("@mui/icons-material/TouchAppSharp");

/***/ }),

/***/ 6715:
/***/ ((module) => {

module.exports = require("@mui/lab/AdapterDateFns");

/***/ }),

/***/ 2089:
/***/ ((module) => {

module.exports = require("@mui/lab/DatePicker");

/***/ }),

/***/ 9904:
/***/ ((module) => {

module.exports = require("@mui/lab/LocalizationProvider");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 5612:
/***/ ((module) => {

module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 1598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 6042:
/***/ ((module) => {

module.exports = require("@mui/material/TextField");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3142:
/***/ ((module) => {

module.exports = require("notistack");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 7051:
/***/ ((module) => {

module.exports = require("react-chartjs-2");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3655:
/***/ ((module) => {

module.exports = require("recharts");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,257,9,776,972,832], () => (__webpack_exec__(3720)));
module.exports = __webpack_exports__;

})();