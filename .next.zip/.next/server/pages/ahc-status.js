"use strict";
(() => {
var exports = {};
exports.id = 262;
exports.ids = [262];
exports.modules = {

/***/ 6871:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AHCStatus),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: external "@mui/material/Grid"
var Grid_ = __webpack_require__(5612);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);
// EXTERNAL MODULE: external "@mui/material/FormGroup"
var FormGroup_ = __webpack_require__(8860);
var FormGroup_default = /*#__PURE__*/__webpack_require__.n(FormGroup_);
// EXTERNAL MODULE: external "@mui/material/FormControlLabel"
var FormControlLabel_ = __webpack_require__(8185);
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel_);
// EXTERNAL MODULE: external "@mui/material/Switch"
var Switch_ = __webpack_require__(3191);
var Switch_default = /*#__PURE__*/__webpack_require__.n(Switch_);
// EXTERNAL MODULE: ./Layout/Layout.js + 9 modules
var Layout = __webpack_require__(1776);
// EXTERNAL MODULE: ./utils/DataStore.js
var DataStore = __webpack_require__(7820);
// EXTERNAL MODULE: ./utils/db.js
var db = __webpack_require__(9972);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./models/Organisation.js

const organisationSchema = new (external_mongoose_default()).Schema({
    name: {
        type: String,
        required: true
    },
    tagline: {
        type: String,
        required: true
    },
    logo: {
        type: String,
        required: true
    },
    FF01_I05_status: {
        type: Boolean,
        required: true
    },
    FF01_I04_status: {
        type: Boolean,
        required: true
    },
    AC1: {
        type: Boolean,
        required: false
    },
    AC2: {
        type: Boolean,
        required: false
    },
    AC3: {
        type: Boolean,
        required: false
    },
    AC4: {
        type: Boolean,
        required: false
    },
    Humidifier1: {
        type: Boolean,
        required: false
    },
    Humidifier2: {
        type: Boolean,
        required: false
    },
    Humidifier3: {
        type: Boolean,
        required: false
    },
    Humidifier4: {
        type: Boolean,
        required: false
    },
    Chillar1: {
        type: Boolean,
        required: false
    },
    Chillar2: {
        type: Boolean,
        required: false
    },
    Chillar3: {
        type: Boolean,
        required: false
    },
    Chillar4: {
        type: Boolean,
        required: false
    }
});
const Organisation = (external_mongoose_default()).models.Organisation || external_mongoose_default().model('Organisation', organisationSchema, 'organisation');
/* harmony default export */ const models_Organisation = (Organisation);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "notistack"
var external_notistack_ = __webpack_require__(3142);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./pages/ahc-status.jsx















function AHCStatus({ organisation  }) {
    const { state  } = (0,external_react_.useContext)(DataStore/* DataStore */.K);
    const { userInfo  } = state;
    const router = (0,router_.useRouter)();
    const { enqueueSnackbar , closeSnackbar  } = (0,external_notistack_.useSnackbar)();
    const { 0: ac1Status , 1: setAC1Status  } = (0,external_react_.useState)(false);
    const { 0: ac2Status , 1: setAC2Status  } = (0,external_react_.useState)(false);
    const { 0: ac3Status , 1: setAC3Status  } = (0,external_react_.useState)(false);
    const { 0: ac4Status , 1: setAC4Status  } = (0,external_react_.useState)(false);
    const { 0: humidifier1Status , 1: setHumidifier1Status  } = (0,external_react_.useState)(false);
    const { 0: humidifier2Status , 1: setHumidifier2Status  } = (0,external_react_.useState)(false);
    const { 0: humidifier3Status , 1: setHumidifier3Status  } = (0,external_react_.useState)(false);
    const { 0: humidifier4Status , 1: setHumidifier4Status  } = (0,external_react_.useState)(false);
    const { 0: chillar1Status , 1: setChillar1Status  } = (0,external_react_.useState)(false);
    const { 0: chillar2Status , 1: setChillar2Status  } = (0,external_react_.useState)(false);
    const { 0: chillar3Status , 1: setChillar3Status  } = (0,external_react_.useState)(false);
    const { 0: chillar4Status , 1: setChillar4Status  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        if (!userInfo) {
            router.push('/login');
        }
        async function run() {
            let { data  } = await external_axios_default().get(`/api/getAHCStatus`);
            await setAC1Status(data.ac1);
            await setAC2Status(data.ac2);
            await setAC3Status(data.ac3);
            await setAC4Status(data.ac4);
            await setHumidifier1Status(data.humidifier1);
            await setHumidifier2Status(data.humidifier2);
            await setHumidifier3Status(data.humidifier3);
            await setHumidifier4Status(data.humidifier4);
            await setChillar1Status(data.chillar1);
            await setChillar2Status(data.chillar2);
            await setChillar3Status(data.chillar3);
            await setChillar4Status(data.chillar4);
        }
        run();
    // setAC1Status(organisation[0].AC1)
    // setAC2Status(organisation[0].AC2)
    // setAC3Status(organisation[0].AC3)
    // setAC4Status(organisation[0].AC4)
    // setHumidifier1Status(organisation[0].Humidifier1)
    // setHumidifier2Status(organisation[0].Humidifier2)
    // setHumidifier3Status(organisation[0].Humidifier3)
    // setHumidifier4Status(organisation[0].Humidifier4)
    // setChillar1Status(organisation[0].Chillar1)
    // setChillar2Status(organisation[0].Chillar2)
    // setChillar3Status(organisation[0].Chillar3)
    // setChillar4Status(organisation[0].Chillar4)
    }, [
        userInfo,
        router
    ]);
    async function OnOffDevice(status, setStatus, name) {
        if (status == true) {
            OffDevice(setStatus, name);
        } else {
            OnDevice(setStatus, name);
        }
    }
    async function OnDevice(setStatus, name) {
        closeSnackbar();
        try {
            setStatus(true);
            await external_axios_default().post(`/api/setAHCStatus`, {
                name: name,
                status: true
            });
            enqueueSnackbar("Updated ", {
                variant: "success"
            });
        } catch (e) {
            console.log(e);
        }
    }
    async function OffDevice(setStatus, name) {
        closeSnackbar();
        try {
            setStatus(flase);
            await external_axios_default().post(`/api/setAHCStatus`, {
                name: name,
                status: false
            });
            enqueueSnackbar("Updated ", {
                variant: "success"
            });
        } catch (e) {
            console.log(e);
        }
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                container: true,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "AC 1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(ac1Status, setAC1Status, 'AC1')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: ac1Status === true ? true : false
                                        }),
                                        label: ac1Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "AC 2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(ac2Status, setAC2Status, 'AC2')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: ac2Status === true ? true : false
                                        }),
                                        label: ac2Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "AC 3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(ac3Status, setAC3Status, 'AC3')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: ac3Status === true ? true : false
                                        }),
                                        label: ac3Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "AC 4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(ac4Status, setAC4Status, 'AC4')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: ac4Status === true ? true : false
                                        }),
                                        label: ac4Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                container: true,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "Humidifier 1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(humidifier1Status, setHumidifier1Status, 'Humidifier1')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: humidifier1Status === true ? true : false
                                        }),
                                        label: humidifier1Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "Humidifier 2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(humidifier2Status, setHumidifier2Status, 'Humidifier2')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: humidifier2Status === true ? true : false
                                        }),
                                        label: humidifier2Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "Humidifier 3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(humidifier3Status, setHumidifier3Status, 'Humidifier3')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: humidifier3Status === true ? true : false
                                        }),
                                        label: humidifier3Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "Humidifier 4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(humidifier4Status, setHumidifier4Status, 'Humidifier4')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: humidifier4Status === true ? true : false
                                        }),
                                        label: humidifier4Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                container: true,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "Chillar 1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(chillar1Status, setChillar1Status, 'Chillar1')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: chillar1Status === true ? true : false
                                        }),
                                        label: chillar1Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "Chillar 2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(chillar2Status, setChillar2Status, 'Chillar2')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: chillar2Status === true ? true : false
                                        }),
                                        label: chillar2Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "Chillar 3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(chillar3Status, setChillar3Status, 'Chillar3')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: chillar3Status === true ? true : false
                                        }),
                                        label: chillar3Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mb: 3
                                },
                                variant: "h5",
                                children: "Chillar 4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    "& > :not(style)": {
                                        m: 1
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormGroup_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        onChange: ()=>OnOffDevice(chillar4Status, setChillar4Status, 'Chillar4')
                                        ,
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                            size: "large",
                                            color: "warning",
                                            checked: chillar4Status === true ? true : false
                                        }),
                                        label: chillar4Status === true ? 'On' : 'Off'
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
async function getServerSideProps() {
    await db/* default.connect */.Z.connect();
    const organisation = await models_Organisation.find({}).lean();
    await db/* default.disconnect */.Z.disconnect();
    return {
        props: {
            organisation: organisation.map(db/* default.convertDocToObj */.Z.convertDocToObj)
        }
    };
}


/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 4628:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles/colorManipulator");

/***/ }),

/***/ 2105:
/***/ ((module) => {

module.exports = require("@material-ui/icons");

/***/ }),

/***/ 3349:
/***/ ((module) => {

module.exports = require("@material-ui/styles");

/***/ }),

/***/ 6464:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountTree");

/***/ }),

/***/ 9560:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AddTask");

/***/ }),

/***/ 1709:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CellTowerSharp");

/***/ }),

/***/ 1050:
/***/ ((module) => {

module.exports = require("@mui/icons-material/DataObject");

/***/ }),

/***/ 5711:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SensorsSharp");

/***/ }),

/***/ 4428:
/***/ ((module) => {

module.exports = require("@mui/icons-material/StorageSharp");

/***/ }),

/***/ 752:
/***/ ((module) => {

module.exports = require("@mui/icons-material/TouchAppSharp");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 8185:
/***/ ((module) => {

module.exports = require("@mui/material/FormControlLabel");

/***/ }),

/***/ 8860:
/***/ ((module) => {

module.exports = require("@mui/material/FormGroup");

/***/ }),

/***/ 5612:
/***/ ((module) => {

module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 3191:
/***/ ((module) => {

module.exports = require("@mui/material/Switch");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3142:
/***/ ((module) => {

module.exports = require("notistack");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,257,9,776,972], () => (__webpack_exec__(6871)));
module.exports = __webpack_exports__;

})();