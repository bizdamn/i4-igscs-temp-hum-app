"use strict";
(() => {
var exports = {};
exports.id = 631;
exports.ids = [631];
exports.modules = {

/***/ 5684:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ DevicePage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material/Grid"
var Grid_ = __webpack_require__(5612);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./utils/db.js
var db = __webpack_require__(9972);
// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./models/Devices.js

const devicesSchema = new (external_mongoose_default()).Schema({
    deviceName: {
        type: String,
        required: true,
        unique: true
    },
    type: {
        type: String,
        required: true
    },
    timestamp: {
        type: Date,
        required: true
    }
});
const Devices = (external_mongoose_default()).models.Devices || external_mongoose_default().model('Devices', devicesSchema, 'devices');
/* harmony default export */ const models_Devices = (Devices);

// EXTERNAL MODULE: ./Layout/Layout.js + 9 modules
var Layout = __webpack_require__(1776);
// EXTERNAL MODULE: ./utils/DataStore.js
var DataStore = __webpack_require__(7820);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./pages/devices.jsx




// components






function DevicePage({ devices  }) {
    const { state  } = (0,external_react_.useContext)(DataStore/* DataStore */.K);
    const { userInfo  } = state;
    const router = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        if (!userInfo) {
            router.push('/login');
        }
    }, [
        userInfo,
        router
    ]);
    console.log(devices);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                sx: {
                    mb: 3
                },
                variant: "h4",
                children: "Devices"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                container: true,
                spacing: 0,
                direction: "column",
                alignItems: "center",
                justifyContent: "center",
                style: {
                    overflowX: 'scroll'
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                    className: "table table-striped table-hover",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                            style: {
                                backgroundColor: '#38B6FF',
                                fontSize: '1.3rem',
                                color: '#fff'
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                        children: "Device Name"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                        children: "Type"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                            children: devices.map((element)=>{
                                return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: `/device-info/${element.deviceName}`,
                                                style: {
                                                    color: 'black'
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    children: element.deviceName
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: `/device-info/${element.deviceName}`,
                                                style: {
                                                    color: 'black'
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    children: element.type
                                                })
                                            })
                                        })
                                    ]
                                }, element.deviceName));
                            })
                        })
                    ]
                })
            })
        ]
    }));
};
async function getServerSideProps() {
    await db/* default.connect */.Z.connect();
    const devices = await models_Devices.find({}).sort({
        'timestamp': -1
    }).limit(300).lean();
    await db/* default.disconnect */.Z.disconnect();
    return {
        props: {
            devices: devices.map(db/* default.convertDocToObj */.Z.convertDocToObj)
        }
    };
}


/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 4628:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles/colorManipulator");

/***/ }),

/***/ 2105:
/***/ ((module) => {

module.exports = require("@material-ui/icons");

/***/ }),

/***/ 3349:
/***/ ((module) => {

module.exports = require("@material-ui/styles");

/***/ }),

/***/ 6464:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountTree");

/***/ }),

/***/ 9560:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AddTask");

/***/ }),

/***/ 1709:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CellTowerSharp");

/***/ }),

/***/ 1050:
/***/ ((module) => {

module.exports = require("@mui/icons-material/DataObject");

/***/ }),

/***/ 5711:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SensorsSharp");

/***/ }),

/***/ 4428:
/***/ ((module) => {

module.exports = require("@mui/icons-material/StorageSharp");

/***/ }),

/***/ 752:
/***/ ((module) => {

module.exports = require("@mui/icons-material/TouchAppSharp");

/***/ }),

/***/ 5612:
/***/ ((module) => {

module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,257,9,776,972], () => (__webpack_exec__(5684)));
module.exports = __webpack_exports__;

})();