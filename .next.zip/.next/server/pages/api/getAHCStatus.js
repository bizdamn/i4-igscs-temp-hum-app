"use strict";
(() => {
var exports = {};
exports.id = 38;
exports.ids = [38];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 5616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 3381:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const entriesSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    name: {
        type: String,
        required: true
    },
    status: {
        type: Boolean,
        required: true
    }
}, {
    timestamps: true
});
const AHCStatusEntries = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.AHCStatusEntries) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('AHCStatusEntries', entriesSchema, 'ahc-status');
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AHCStatusEntries);


/***/ }),

/***/ 4468:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3381);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4323);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])();
handler.get(async (req, res)=>{
    await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* ["default"].connect */ .Z.connect();
    const ac1 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'AC1'
    }).sort({
        timestamp: -1
    }).limit(1);
    const ac2 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'AC2'
    }).sort({
        timestamp: -1
    }).limit(1);
    const ac3 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'AC3'
    }).sort({
        timestamp: -1
    }).limit(1);
    const ac4 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'AC4'
    }).sort({
        timestamp: -1
    }).limit(1);
    const humidifier1 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'Humidifier1'
    }).sort({
        timestamp: -1
    }).limit(1);
    const humidifier2 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'Humidifier2'
    }).sort({
        timestamp: -1
    }).limit(1);
    const humidifier3 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'Humidifier3'
    }).sort({
        timestamp: -1
    }).limit(1);
    const humidifier4 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'Humidifier4'
    }).sort({
        timestamp: -1
    }).limit(1);
    const chillar1 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'Chillar1'
    }).sort({
        timestamp: -1
    }).limit(1);
    const chillar2 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'Chillar2'
    }).sort({
        timestamp: -1
    }).limit(1);
    const chillar3 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'Chillar3'
    }).sort({
        timestamp: -1
    }).limit(1);
    const chillar4 = await _models_AHCStatusEntries__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({
        name: 'Chillar4'
    }).sort({
        timestamp: -1
    }).limit(1);
    await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* ["default"].disconnect */ .Z.disconnect();
    res.send({
        ac1: ac1[0].status,
        ac2: ac2[0].status,
        ac3: ac3[0].status,
        ac4: ac4[0].status,
        humidifier1: humidifier1[0].status,
        humidifier2: humidifier2[0].status,
        humidifier3: humidifier3[0].status,
        humidifier4: humidifier4[0].status,
        chillar1: chillar1[0].status,
        chillar2: chillar2[0].status,
        chillar3: chillar3[0].status,
        chillar4: chillar4[0].status
    });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [323], () => (__webpack_exec__(4468)));
module.exports = __webpack_exports__;

})();