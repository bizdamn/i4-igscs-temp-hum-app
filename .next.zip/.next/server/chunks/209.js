"use strict";
exports.id = 209;
exports.ids = [209];
exports.modules = {

/***/ 209:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_0__);

const data = {
    organisation: [
        {
            name: 'Marelli India',
            tagline: 'Marelli India',
            logo: '/',
            FF01_I04_status: false,
            FF01_I05_status: false
        }
    ],
    users: [
        {
            name: 'IGSCS',
            email: 'igscs@gmail.com',
            password: bcryptjs__WEBPACK_IMPORTED_MODULE_0___default().hashSync('IGSCS041173WelcomeChirpstack'),
            isAdmin: true,
            isSuperAdmin: true
        },
        {
            name: 'Admin_1',
            email: 'ashish.dangi@marelli.com',
            password: bcryptjs__WEBPACK_IMPORTED_MODULE_0___default().hashSync('12345678'),
            isAdmin: true,
            isSuperAdmin: false
        },
        {
            name: 'User_1',
            email: 'ashish.dangi@marelli.com',
            password: bcryptjs__WEBPACK_IMPORTED_MODULE_0___default().hashSync('87654321'),
            isAdmin: false,
            isSuperAdmin: false
        }, 
    ],
    entries: [
        {
            deviceName: 'dht11_01',
            temperature: 23,
            humidity: 53,
            timestamp: new Date()
        },
        {
            deviceName: 'dht22_01',
            temperature: 20,
            humidity: 52,
            timestamp: new Date()
        },
        {
            deviceName: 'dht22_02',
            temperature: 21,
            humidity: 53,
            timestamp: new Date()
        },
        {
            deviceName: 'dht11_01',
            temperature: 24,
            humidity: 53,
            timestamp: new Date()
        },
        {
            deviceName: 'dht22_01',
            temperature: 29,
            humidity: 52,
            timestamp: new Date()
        },
        {
            deviceName: 'dht22_02',
            temperature: 30,
            humidity: 53,
            timestamp: new Date()
        },
        {
            deviceName: 'dht11_01',
            temperature: 23,
            humidity: 53,
            timestamp: new Date()
        },
        {
            deviceName: 'dht22_01',
            temperature: 20,
            humidity: 52,
            timestamp: new Date()
        },
        {
            deviceName: 'dht22_02',
            temperature: 21,
            humidity: 53,
            timestamp: new Date()
        }
    ],
    ahcStatusCollection: [
        {
            name: 'AC1',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'AC2',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'AC3',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'AC4',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'Humidifier1',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'Humidifier2',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'Humidifier3',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'Humidifier4',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'Chillar1',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'Chillar2',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'Chillar3',
            status: false,
            timestamp: new Date()
        },
        {
            name: 'Chillar4',
            status: false,
            timestamp: new Date()
        }, 
    ]
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (data);


/***/ })

};
;